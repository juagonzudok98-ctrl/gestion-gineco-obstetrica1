GESTIÓN GINECO-OBSTÉTRICA — PROTOTIPO
Dr. Juan Gabriel González Díaz

INCLUIDO
- Registro local de pacientes de prueba
- Registro de consultas y evolución
- Historia ginecológica y obstétrica
- Control gestacional con cálculos por FUM y por edad gestacional informada en ecografía
- Agenda de próximos controles
- Exportación JSON y CSV

CÓMO ABRIR
1. Descomprima el archivo ZIP en una computadora.
2. Abra index.html con Chrome, Edge, Firefox o Safari.
3. Use únicamente datos ficticios.

LIMITACIONES IMPORTANTES
- No está conectado a la nube.
- Los datos se almacenan en el almacenamiento local del navegador y no se sincronizan entre dispositivos.
- No es una historia clínica validada ni un sistema seguro para datos reales.
- La edad gestacional y FPP son cálculos auxiliares. Verifique siempre la datación y la FPP según criterio clínico y guías vigentes.
- La función de notificaciones solo usa permisos del navegador y no envía recordatorios externos; no funcionará como servicio de recordatorios si la página está cerrada.
- No se han configurado usuarios, autenticación, controles de acceso, cifrado de base de datos ni copias de seguridad automáticas.

Para uso clínico real, hace falta desarrollar y auditar una versión con base de datos en la nube, autenticación individual, reglas de acceso por paciente/usuario, copias de seguridad, HTTPS y cumplimiento de los requisitos legales de protección de datos aplicables.
