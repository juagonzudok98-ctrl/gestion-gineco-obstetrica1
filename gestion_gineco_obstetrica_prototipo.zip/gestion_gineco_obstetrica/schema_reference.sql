-- ESQUEMA DE REFERENCIA (NO CONFIGURADO NI VALIDADO PARA PRODUCCIÓN)
-- No ejecutar como sistema clínico sin revisión técnica y de seguridad.
create table patients (
  id uuid primary key default gen_random_uuid(),
  full_name text not null,
  date_of_birth date,
  internal_code text,
  created_at timestamptz not null default now()
);
create table consultations (
  id uuid primary key default gen_random_uuid(),
  patient_id uuid not null references patients(id) on delete cascade,
  consultation_date date not null,
  consultation_type text,
  diagnosis text,
  findings text,
  plan text,
  next_control date,
  created_at timestamptz not null default now()
);
create table prenatal_controls (
  id uuid primary key default gen_random_uuid(),
  patient_id uuid not null references patients(id) on delete cascade,
  assessment_date date not null,
  lmp date,
  edd_lmp date,
  ultrasound_date date,
  ultrasound_ga_weeks integer,
  ultrasound_ga_days integer,
  edd_ultrasound date,
  next_control date,
  high_risk_flag boolean not null default false,
  notes text,
  created_at timestamptz not null default now()
);
-- Antes de producción: habilitar RLS, crear políticas estrictas ligadas a usuarios
-- autenticados, probar aislamiento entre cuentas, y configurar copias de seguridad.
